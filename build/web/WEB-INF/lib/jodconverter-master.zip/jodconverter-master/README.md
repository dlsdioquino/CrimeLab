JODConverter
============

JODConverter (for Java OpenDocument Converter) automates document conversions
using LibreOffice or OpenOffice.org.

I started this project back in 2003, but I am no longer maintaining it. I moved
the code here at GitHub in the hope that a well-maintained fork will emerge.

See the [Google Code](http://code.google.com/p/jodconverter/) project for more
info.


JODConverter
============

This is JODConverter 3.0 beta.

JODConverter automates conversions between office document formats
using LibreOffice or Apache OpenOffice. 

See http://jodconverter.googlecode.com for the latest documentation.

Licensing
---------

JODConverter is open source software, you can redistribute it and/or
modify it under either (at your option) of the following licenses

1. The GNU Lesser General Public License v3 (or later)
   -> see LICENSE-LGPL.txt
2. The Apache License, Version 2.0
   -> see LICENSE-Apache.txt
